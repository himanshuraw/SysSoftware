#include "../Structures/feedback.h"

#include <stdbool.h>
#include <stdio.h>

#include "../Structures/constants.h"

int main() {
    struct Feedback feedback;
    FILE *file =
        fopen("../Records/feedback.txt", "rb");  // Open the file in binary mode

    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }

    // Read and print each feedback record one by one
    while (fread(&feedback, sizeof(struct Feedback), 1, file) == 1) {
        // Print the feedback details
        printf("Feedback ID: %d\n", feedback.id);
        printf("Reviewed: %s\n", feedback.reviewed ? "Yes" : "No");
        printf("Text: %s\n", feedback.text);
        printf("------------------------\n");
    }

    // Close the file
    fclose(file);

    return 0;
}
