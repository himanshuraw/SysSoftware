#include "../Structures/loan.h"

#include <stdbool.h>
#include <stdio.h>
#include <string.h>

int main() {
    struct Loan loan;
    FILE *file =
        fopen("../Records/loan.txt", "rb");  // Open the file in binary mode

    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }

    while (EOF) {
        // Read the data into the Loan structure
        if (fread(&loan, sizeof(struct Loan), 1, file) != 1) {
            perror("Error reading file");
            fclose(file);
            return 1;
        }
        char status[10];
        if (loan.status == -1) {
            strcpy(status, "Pending");
        } else if (loan.status == 0) {
            strcpy(status, "Rejected");
        } else {
            strcpy(status, "Approved");
        }

        // Print the loan details
        printf("Loan ID: %d\n", loan.id);
        printf("Amount: %ld\n", loan.amount);
        printf("Customer Account Number: %d\n", loan.customer_account_number);
        printf("Status: %s\n", status);
        printf("Assigned: %s\n", loan.assigned ? "Yes" : "No");
    }
    fclose(file);

    return 0;
}
