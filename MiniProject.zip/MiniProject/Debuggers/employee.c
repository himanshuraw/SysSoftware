#include "../Structures/employee.h"

#include <stdio.h>

#include "../Structures/constants.h"

int main() {
    struct Employee emp;
    FILE *file =
        fopen("../Records/employee.txt", "rb");  // Open the binary file

    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }

    while (EOF) {
        // Read the data into the Employee structure
        if (fread(&emp, sizeof(struct Employee), 1, file) != 1) {
            perror("Error reading file");
            return 1;
        }

        // Print the employee details
        printf("Employee ID: %d\n", emp.id);
        printf("Name: %s\n", emp.name);
        printf("Gender: %c\n", emp.gender);
        printf("Age: %d\n", emp.age);

        // Decode the role
        if (emp.role == 0) {
            printf("Role: Employee\n");
        } else if (emp.role == 1) {
            printf("Role: Manager\n");
        } else {
            printf("Role: Unknown (%d)\n", emp.role);
        }
        for (int i = 0; i < LOAN_SIZE; i++) {
            printf("%d ", emp.loans[i]);
        }
        printf("\nptr: %d\n", emp.ptr);

        printf("Username: %s\n", emp.username);
        printf("Password: %s\n", emp.password);
    }

    // Close the file
    fclose(file);

    return 0;
}
