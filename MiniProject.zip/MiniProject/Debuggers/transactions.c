#include <stdio.h>
#include <time.h>

#include "../Structures/transaction.h"

int main() {
    struct Transaction tx;
    FILE *file =
        fopen("../Records/transaction.txt", "rb");  // Open the binary file

    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }

    while (EOF) {
        // Read the data into the Transaction structure
        if (fread(&tx, sizeof(struct Transaction), 1, file) != 1) {
            perror("Error reading file");
            return 1;
        }

        // Print the transaction details
        printf("Transaction ID: %d\n", tx.id);
        printf("Account Number: %d\n", tx.account_number);
        printf("Amount: %.2f\n", tx.amount);

        // Decode the operation
        const char *operation_str[] = {"Deposit", "Withdraw", "Transfer_in",
                                       "Transfer_out"};
        if (tx.operation >= 0 && tx.operation <= 3) {
            printf("Operation: %s\n", operation_str[tx.operation]);
        } else {
            printf("Operation: Unknown (%d)\n", tx.operation);
        }

        // Print the time
        printf("Time: %s", ctime(&tx.time));
    }
    // Close the file
    fclose(file);
    return 0;
}
