#include "../Structures/customer.h"

#include <stdbool.h>
#include <stdio.h>

int main() {
    struct Customer customer;
    FILE *file =
        fopen("../Records/customer.txt", "rb");  // Open the binary file

    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }
    while (EOF) {
        // Read the data into the Customer structure
        if (fread(&customer, sizeof(struct Customer), 1, file) != 1) {
            perror("Error reading file");
            return 1;
        }

        // Close the file

        // Print the customer details

        printf("Name: %s\n", customer.name);
        printf("Gender: %c\n", customer.gender);
        printf("Age: %d\n", customer.age);
        printf("Username: %s\n", customer.username);
        printf("Password: %s\n", customer.password);
        printf("Account Number: %d\n", customer.account_number);
        printf("loan-id: %d\n", customer.loan);
        printf("Account Active: %s\n", customer.is_active ? "Yes" : "No");
        printf("Balance: %.2f\n", customer.balance);

        // Print transaction history
        printf("Transactions: ");

        for (int i = 0; i < MAX_TRANSACTIONS; i++) {
            int index = customer.ptr - i - 1;
            if (index < 0) {
                index = MAX_TRANSACTIONS + index;
            }
            if (customer.transactions[index] == 0) {
                continue;
            }
            printf("%d ", customer.transactions[index]);
        }
        printf("\n");

        // Print the pointer indicating the number of transactions
        printf("Transaction Pointer: %d\n", customer.ptr);
        printf("\n");
    }
    fclose(file);
    return 0;
}
